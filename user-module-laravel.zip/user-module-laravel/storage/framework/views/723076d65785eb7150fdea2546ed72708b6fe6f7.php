<div id="sidebar" class="sidebar responsive">
    <ul class="nav nav-list">
        <li >
            <a href="./">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Dashboard </span>
            </a>

            <b class="arrow"></b>
        </li>
            <li >
                <a href="./employee">
                    <i class="menu-icon fa fa-users"></i>
                    <span class="menu-text"> Employees </span>
                </a>
            </li>

            <li >
                <a href="./clients">
                    <i class="menu-icon fa fa-user"></i>
                    <span class="menu-text"> Clients </span>
                </a>
            </li>


</ul><!-- /.nav-list -->

<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
    <i class="ace-icon fa fa-angle-double-left" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
</div>
</div>